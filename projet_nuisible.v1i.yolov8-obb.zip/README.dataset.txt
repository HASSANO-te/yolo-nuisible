# projet_nuisible > 2025-10-20 2:13pm
https://universe.roboflow.com/ibrahim-kew92/projet_nuisible-9kil7

Provided by a Roboflow user
License: MIT

